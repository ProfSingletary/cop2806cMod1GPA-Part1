package chapter01;
public interface MessageService {
 public String getMessage();
}
